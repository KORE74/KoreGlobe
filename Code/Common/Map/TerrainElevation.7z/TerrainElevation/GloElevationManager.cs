using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

#nullable enable

// Overarching class to manage elevation activities, including background tasks around the loading and creating.

public class GloElevationManager
{
    // Consume general Arc ASCII grid files and output elevations for a lat/lon.
    private GloElevationPrepSystem ElePrep = new();

    // Hold map tiles for use in display. Load/save tiles for caching work.
    private GloElevationTileSystem EleTiles = new();

    // Semaphore to limit the number of concurrent tasks.
    private static readonly SemaphoreSlim semaphore = new(10); // Adjust the number as needed.

    // --------------------------------------------------------------------------------------------
    // MARK: Prep
    // --------------------------------------------------------------------------------------------

    public void LoadArcASCIIGridFile(string filename, GloLLBox llBox)
    {
        Task.Run(async() =>
        {
            await semaphore.WaitAsync(); // Wait for an available slot
            try
            {
                GloElevationPrepTile? newTile = ElePrep.ArcASCIIToTile(filename, llBox);

                if (newTile != null)
                {
                    GloCentralLog.AddEntry($"Failed to load Arc ASCII Grid: {filename} // {llBox}");
                }
            }
            finally
            {
                semaphore.Release(); // Release the slot
            }
        });
    }

    // --------------------------------------------------------------------------------------------
    // MARK: Tiles
    // --------------------------------------------------------------------------------------------

    // Non-blocking call to start the tile preparation activities, that will require nested looping through
    // a large number of LL pairs.
    public void PrepTile(GloMapTileCode tileCode, bool saveFile)
    {
        Task.Run(async() =>
        {
            //await semaphore.WaitAsync(); // Wait for an available slot
            try
            {
                // Setup the tile defining values
                GloLLBox llBox      = tileCode.LLBox;
                int      tileResLat = 100;
                int      tileResLon = GloElevationPrepTile.GetLongitudeResolution(tileResLat, llBox.CenterPoint.LatDegs);

                // Big operation: get the 2D array of elevations, which itself may require interpolation across nested arrays.
                GloFloat2DArray eleData = GloElevationTileSystem.PrepTileData(ElePrep, llBox, tileResLat, tileResLon);

                // Create the new tile and add it to the collection
                GloElevationTile newTile = new() {
                    TileCode      = tileCode,
                    ElevationData = eleData,
                    LLBox         = llBox
                };

                if (saveFile)
                {
                    GloMapTileFilepaths filepaths = new(tileCode);
                    try
                    {
                        GloElevationTileIO.WriteToTextFile(newTile, filepaths.EleArrFilepath);
                    }
                    catch (Exception ex)
                    {
                        GloCentralLog.AddEntry($"Failed to write: {filepaths.EleArrFilepath}");
                    }
                }

                EleTiles.AddTile(newTile);
            }
            catch(Exception ex)
            {
                GloCentralLog.AddEntry($"{ex.Message}");
            }
            //finally
            //{
                //semaphore.Release(); // Release the slot
            //}
        });
    }

    // --------------------------------------------------------------------------------------------

    public void LoadTile(GloMapTileCode tileCode)
    {
        Task.Run(async() =>
        {
            await semaphore.WaitAsync(); // Wait for an available slot
            try
            {
                // Avoid the workload if tile already exists
                if (HasTile(tileCode))
                    return;

                // Get the filepaths
                GloMapTileFilepaths filepaths = new GloMapTileFilepaths(tileCode);

                LoadTileFile(filepaths.EleArrFilepath);
            }
            finally
            {
                semaphore.Release(); // Release the slot
            }
        });
    }

    private void LoadTileFile(string filepath)
    {
        try
        {
            GloElevationTile? newTile = GloElevationTileIO.ReadFromTextFile(filepath);
            if (newTile != null)
                EleTiles.AddTile(newTile!);
            else
                GloCentralLog.AddEntry($"Failed to load file: {filepath}");
        }
        catch (Exception ex)
        {
            GloCentralLog.AddEntry($"EXCEPTION: Failed to load file: {filepath}");
        }
    }

    public bool             HasTile(GloMapTileCode tileCode)    => EleTiles.HasTile(tileCode.TileCode);
    public GloElevationTile GetTile(GloMapTileCode tileCode)    => EleTiles.GetTile(tileCode.TileCode); // Returns a default tile when not found, use HasTile first
    public void             DeleteTile(GloMapTileCode tileCode) => EleTiles.DeleteTile(tileCode.TileCode);
    public void             DeleteAllTiles()                    => EleTiles.DeleteAllTiles();

    // --------------------------------------------------------------------------------------------
    // MARK: High-Level task
    // --------------------------------------------------------------------------------------------

    // Function called by a tile that wants the elevation tile for it, and doesn't care about the complexity required to acheive that.
    // This function exists to perform whater tasks are required to supply that data, through the HasTile() and GetTile() calls.

    public void RequestTile(GloMapTileCode tileCode)
    {
        Task.Run(async() =>
        {
            await semaphore.WaitAsync(); // Wait for an available slot
            try
            {
                // Avoid the workload if tile already exists
                if (HasTile(tileCode))
                    return;

                // Get the filepaths
                GloMapTileFilepaths filepaths = new GloMapTileFilepaths(tileCode);

                // If a saved tile exists, load that.
                if (filepaths.EleArrFileExists)
                {
                    LoadTileFile(filepaths.EleArrFilepath);
                    return;
                }

                // No pre-existing tile, so get one from the Prep area
                PrepTile(tileCode, true);
            }
            finally
            {
                semaphore.Release(); // Release the slot
            }
        });
    }

}

