


public class GloElevationTile
{
    public GloLLBox        LLBox;
    public GloFloat2DArray ElevationData;
    public GloMapTileCode  TileCode;

    // Zero tile
    public static GloElevationTile Zero
    {
        get { return new GloElevationTile(); }
    }
}
