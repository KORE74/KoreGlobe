using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Text;

#nullable enable

// GloElevationTileSystem: A class to contain a list of map tile elevations that can be looked up when required.
// Tiles can be created from the ElevationPrepSystem, or loaded/saved to file.

public class GloElevationTileSystem
{
    // List of tile elevations, indexed by the tilecode string.
    private ConcurrentDictionary<string, GloElevationTile> TileList = new();

    // Time for textures to keep alive (in seconds).
    private const int KeepAliveTime = 10;
    private ConcurrentDictionary<string, int> LastAccessTime = new ConcurrentDictionary<string, int>();

    // --------------------------------------------------------------------------------------------
    // MARK: Tile Collection
    // --------------------------------------------------------------------------------------------

    public void AddTile(GloElevationTile tile)
    {
        string name          = tile.TileCode.TileCode;

        TileList[name]       = tile;
        LastAccessTime[name] = GloCentralTime.RuntimeIntSecs;
    }

    public bool HasTile(string name)
    {
        if (TileList.ContainsKey(name))
        {
            LastAccessTime[name] = GloCentralTime.RuntimeIntSecs;
            return true;
        }
        return false;
    }

    public GloElevationTile GetTile(string name)
    {
        if (TileList.ContainsKey(name))
        {
            LastAccessTime[name] = GloCentralTime.RuntimeIntSecs;
            return TileList[name];
        }
        return GloElevationTile.Zero;
    }

    public void DeleteTile(string name)
    {
        TileList.TryRemove(name, out _);
        LastAccessTime.TryRemove(name, out _);
    }

    public void DeleteAllTiles()
    {
        TileList.Clear();
        LastAccessTime.Clear();
    }

    // --------------------------------------------------------------------------------------------
    // MARK: Static Utils
    // --------------------------------------------------------------------------------------------

    public static GloFloat2DArray PrepTileData(GloElevationPrepSystem elePrepSystem, GloLLBox llBox, int latRes, int lonRes)
    {
        // Create lists of all the lats and lons we would iterate across
        GloFloat1DArray loopLats = GloFloat1DArrayOperations.ListForRange((float)llBox.MinLatDegs, (float)llBox.MaxLatDegs, latRes);
        GloFloat1DArray loopLons = GloFloat1DArrayOperations.ListForRange((float)llBox.MinLonDegs, (float)llBox.MaxLonDegs, lonRes);

        // Create the output 2D list
        GloFloat2DArray retEle = new GloFloat2DArray(latRes, lonRes);

        // Create the current position we'll move acorss the tile
        GloLLPoint currPos = new();

        // Nested loop across the lat and long lists of tile positions
        for (int latIdx = 0; latIdx < loopLats.Length; latIdx++)
        {
            currPos.LatDegs = loopLats[latIdx];
            for (int lonIdx = 0; lonIdx < loopLons.Length; lonIdx++)
            {
                currPos.LonDegs = loopLons[lonIdx];

                // Lookup the best value to this position and put it in our returned array
                retEle[latIdx, lonIdx] = elePrepSystem.ElevationAtPos(currPos);
            }
        }

        return retEle;
    }
}