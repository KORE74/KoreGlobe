

using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading.Tasks;

using Godot;

// Essential information around the tile image and potential sub-area within it.
// Logic:
// - Collection of time expiring images
// - Collection of tile inforation linking to an image and a UVBox.
// - Access always checks that the image has been maintained, prunes tile info when image not found.

public class TileImageInfo
{
    public GloMapTileCode TileCode;
    public Texture2D      TileImage;
    public GloUVBox       UVBox;
}

public partial class GloTileImageManager : Node
{
    // Cache to hold the loading tasks, to avoid duplicating a running task
    private ConcurrentDictionary<string, Task> LoadingTasks = new ConcurrentDictionary<string, Task>();

    // List of the native images
    private ConcurrentDictionary<string, Texture> TextureCache = new();

    // Time for textures to keep alive (in seconds).
    private const int KeepAliveTime = 10;
    private ConcurrentDictionary<string, int> LastAccessTimeList = new ConcurrentDictionary<string, int>();

    // List of the tile information that consumes the images
    private ConcurrentDictionary<GloMapTileCode, TileImageInfo> tileCache = new();


    public void RequestTileImage(GloMapTileCode tilecode)
    {
        // Get the filepaths
        GloMapTileFilepaths filepaths = new GloMapTileFilepaths(tilecode);

        // If the actual image exists, we don't need to search for a parent tile image etc
        if (filepaths.ImageFileExists)
        {
            // if the image is already loaded
            if (HasImage(filepaths.ImageFilepath))
            {

            }
        }
        // if the file exists, check its loaded.


    }

    // --------------------------------------------------------------------------------------------
    // MARK: Image Management
    // --------------------------------------------------------------------------------------------

    // Checks if the image has been loaded and is available in the cache.
    public bool HasImage(string path)
    {
        if (TextureCache.ContainsKey(path))
        {
            LastAccessTimeList[path] = GloCentralTime.RuntimeIntSecs;
            return true;
        }
        return false;
    }

    // Keeps a texture alive by updating its last access time.
    public void KeepAlive(string path)
    {
        if (TextureCache.ContainsKey(path))
        {
            LastAccessTimeList[path] = GloCentralTime.RuntimeIntSecs;
        }
    }

    // --------------------------------------------------------------------------------------------
    // MARK: Expired Tile Deletion
    // --------------------------------------------------------------------------------------------

    private void DeleteExpiredTextures()
    {
        if (TextureCache.Count == 0)
            return;

        int currentTime = GloCentralTime.RuntimeIntSecs;
        foreach (var key in LastAccessTimeList.Keys)
        {
            if (LastAccessTimeList.TryGetValue(key, out int lastAccess) && currentTime - lastAccess > KeepAliveTime)
            {
                // Remove the texture to free up memory.
                if (TextureCache.TryRemove(key, out Texture texture))
                {
                    texture.Dispose();
                    LastAccessTimeList.TryRemove(key, out _);
                }
            }
        }
    }

    // Deletes the oldest, most out-of-date image from the cache.
    public void DeleteOldestExpiredTextures()
    {
        // Delete the oldest image only if it has exceeded the KeepAliveTime.
        if (LastAccessTimeList.Count == 0)
            return;

        var currentTime = GloCentralTime.RuntimeIntSecs;
        var oldestEntry = LastAccessTimeList.OrderBy(kvp => kvp.Value).FirstOrDefault();
        string oldestKey = oldestEntry.Key;

        if (!string.IsNullOrEmpty(oldestKey) &&
            (currentTime - oldestEntry.Value > KeepAliveTime))
        {
            // Only delete the oldest image if it has indeed expired.
            if (TextureCache.TryRemove(oldestKey, out Texture texture))
            {
                texture.Dispose();
                LastAccessTimeList.TryRemove(oldestKey, out _);
            }
        }
    }




    public TileImageInfo GetTileImage(GloMapTileCode tilecode)
    {

    }



    private int ActionTimer = 0;
    private const int ActionTimerIncrement = 2;

    // --------------------------------------------------------------------------------------------
    // MARK: Node functions
    // --------------------------------------------------------------------------------------------

    public override void _Ready()
    {
        Name = "ImageManager";
    }

    // Called every frame to handle the keep-alive functionality.
    public override void _Process(double delta)
    {
        // Periodically delete the expired textures
        if (ActionTimer > GloCentralTime.RuntimeIntSecs)
        {
            ActionTimer = GloCentralTime.RuntimeIntSecs + ActionTimerIncrement;
            //DeleteExpiredTextures();
            DeleteOldestExpiredTextures();
        }
    }

    // --------------------------------------------------------------------------------------------
    // MARK: Start Image Loading
    // --------------------------------------------------------------------------------------------

    // Starts loading an image asynchronously. Non-blocking.
    public async void StartImageLoading(string imagePath)
    {
        Texture texture = await LoadTextureAsync(imagePath);
    }

    // --------------------------------------------------------------------------------------------
    // MARK: Background loading
    // --------------------------------------------------------------------------------------------

    // Loads a texture from a resource path asynchronously.
    private async Task<Texture> LoadTextureAsync(string path)
    {
        if (TextureCache.TryGetValue(path, out Texture existingTexture))
        {
            LastAccessTimeList[path] = GloCentralTime.RuntimeIntSecs;
            return existingTexture;
        }

        if (!LoadingTasks.ContainsKey(path))
        {
            // Load texture in the background.
            Task loadingTask = Task.Run(() =>
            {
                try
                {
                    var image = (Image)ResourceLoader.Load(path);
                    if (image == null)
                    {
                        GD.PrintErr($"Failed to load image at path: {path}");
                        return;
                    }

                    var texture = new ImageTexture();
                    ImageTexture.CreateFromImage(image);

                    TextureCache[path] = texture;
                    LastAccessTimeList[path] = GloCentralTime.RuntimeIntSecs;
                }
                catch (Exception ex)
                {
                    GD.PrintErr("", ex);
                }
            });

            LoadingTasks[path] = loadingTask;
        }

        await LoadingTasks[path];
        LoadingTasks.TryRemove(path, out _);
        TextureCache.TryGetValue(path, out Texture loadedTexture);
        return loadedTexture;
    }



    // --------------------------------------------------------------------------------------------
    // MARK: Ping
    // --------------------------------------------------------------------------------------------


