using System;
using System.Threading.Tasks;
using System.Collections.Concurrent;

using Godot;
using System.Linq;

public partial class GloImageManager : Node
{
    // Cache to hold the textures for map tiles.
    private ConcurrentDictionary<string, Texture> textureCache = new ConcurrentDictionary<string, Texture>();
    private ConcurrentDictionary<string, Task>    loadingTasks = new ConcurrentDictionary<string, Task>();

    // Time for textures to keep alive (in seconds).
    private const int KeepAliveTime = 10;
    private ConcurrentDictionary<string, int> lastAccessTime = new ConcurrentDictionary<string, int>();

    private int ActionTimer = 0;
    private const int ActionTimerIncrement = 2;

    // --------------------------------------------------------------------------------------------
    // MARK: Node functions
    // --------------------------------------------------------------------------------------------

    public override void _Ready()
    {
        Name = "ImageManager";
    }

    // Called every frame to handle the keep-alive functionality.
    public override void _Process(double delta)
    {
        // Periodically delete the expired textures
        if (ActionTimer > GloCentralTime.RuntimeIntSecs)
        {
            ActionTimer = GloCentralTime.RuntimeIntSecs + ActionTimerIncrement;
            //DeleteExpiredTextures();
            DeleteOldestExpiredTextures();
        }
    }

    // --------------------------------------------------------------------------------------------
    // MARK: Start Image Loading
    // --------------------------------------------------------------------------------------------

    // Starts loading an image asynchronously. Non-blocking.
    public async void StartImageLoading(string imagePath)
    {
        Texture texture = await LoadTextureAsync(imagePath);
    }

    // --------------------------------------------------------------------------------------------
    // MARK: Background loading
    // --------------------------------------------------------------------------------------------

    // Loads a texture from a resource path asynchronously.
    private async Task<Texture> LoadTextureAsync(string path)
    {
        if (textureCache.TryGetValue(path, out Texture existingTexture))
        {
            lastAccessTime[path] = GloCentralTime.RuntimeIntSecs;
            return existingTexture;
        }

        if (!loadingTasks.ContainsKey(path))
        {
            // Load texture in the background.
            Task loadingTask = Task.Run(() =>
            {
                try
                {
                    var image = (Image)ResourceLoader.Load(path);
                    if (image == null)
                    {
                        GD.PrintErr($"Failed to load image at path: {path}");
                        return;
                    }

                    var texture = new ImageTexture();
                    ImageTexture.CreateFromImage(image);

                    textureCache[path] = texture;
                    lastAccessTime[path] = GloCentralTime.RuntimeIntSecs;
                }
                catch (Exception ex)
                {
                    GD.PrintErr("", ex);
                }
            });

            loadingTasks[path] = loadingTask;
        }

        await loadingTasks[path];
        loadingTasks.TryRemove(path, out _);
        textureCache.TryGetValue(path, out Texture loadedTexture);
        return loadedTexture;
    }

    // Checks if the image has been loaded and is available in the cache.
    public bool HasImage(string path)
    {
        if (textureCache.ContainsKey(path))
        {
            lastAccessTime[path] = GloCentralTime.RuntimeIntSecs;
            return true;
        }
        return false;
    }


    // --------------------------------------------------------------------------------------------
    // MARK: Ping
    // --------------------------------------------------------------------------------------------

    // Keeps a texture alive by updating its last access time.
    public void KeepAlive(string path)
    {
        if (textureCache.ContainsKey(path))
        {
            lastAccessTime[path] = GloCentralTime.RuntimeIntSecs;
        }
    }

    // --------------------------------------------------------------------------------------------
    // MARK: Expired Tile Deletion
    // --------------------------------------------------------------------------------------------

    private void DeleteExpiredTextures()
    {
        if (textureCache.Count == 0)
            return;

        int currentTime = GloCentralTime.RuntimeIntSecs;
        foreach (var key in lastAccessTime.Keys)
        {
            if (lastAccessTime.TryGetValue(key, out int lastAccess) && currentTime - lastAccess > KeepAliveTime)
            {
                // Remove the texture to free up memory.
                if (textureCache.TryRemove(key, out Texture texture))
                {
                    texture.Dispose();
                    lastAccessTime.TryRemove(key, out _);
                }
            }
        }
    }

    // Deletes the oldest, most out-of-date image from the cache.
    public void DeleteOldestExpiredTextures()
    {
        // Delete the oldest image only if it has exceeded the KeepAliveTime.
        if (lastAccessTime.Count == 0)
            return;

        var currentTime = GloCentralTime.RuntimeIntSecs;
        var oldestEntry = lastAccessTime.OrderBy(kvp => kvp.Value).FirstOrDefault();
        string oldestKey = oldestEntry.Key;

        if (!string.IsNullOrEmpty(oldestKey) &&
            (currentTime - oldestEntry.Value > KeepAliveTime))
        {
            // Only delete the oldest image if it has indeed expired.
            if (textureCache.TryRemove(oldestKey, out Texture texture))
            {
                texture.Dispose();
                lastAccessTime.TryRemove(oldestKey, out _);
            }
        }
    }

}
